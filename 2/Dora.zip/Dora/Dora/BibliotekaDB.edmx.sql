
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 06/02/2021 02:13:03
-- Generated from EDMX file: C:\Users\shand\source\repos\Dora\Dora\FurnitureDB.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Tabela1];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Osobas'
CREATE TABLE [dbo].[Osobas] (
    [JMBG] int IDENTITY(1,1) NOT NULL,
    [Ime] nvarchar(max)  NOT NULL,
    [Prezime] nvarchar(max)  NOT NULL,
    [Mejl] nvarchar(max)  NOT NULL,
    [Adresa] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Clans'
CREATE TABLE [dbo].[Clans] (
    [ID_clana] int IDENTITY(1,1) NOT NULL,
    [OsobaJMBG] int  NOT NULL,
    [Clanarina_Naziv] nvarchar(max)  NOT NULL,
    [Za_Iznajmljivanje_PrimerakID_Primerka] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Clanarinas'
CREATE TABLE [dbo].[Clanarinas] (
    [Naziv] nvarchar(max)  NOT NULL,
    [Cena] int  NOT NULL
);
GO

-- Creating table 'Bibliotekars'
CREATE TABLE [dbo].[Bibliotekars] (
    [ID_Bibliotekara] nvarchar(max)  NOT NULL,
    [Ime] nvarchar(max)  NOT NULL,
    [Prezime] nvarchar(max)  NOT NULL,
    [BibliotekaPIB] nvarchar(max)  NOT NULL,
    [Clanarina_Naziv] nvarchar(max)  NULL
);
GO

-- Creating table 'Bibliotekas'
CREATE TABLE [dbo].[Bibliotekas] (
    [PIB] nvarchar(max)  NOT NULL,
    [Naziv] nvarchar(max)  NOT NULL,
    [Adresa] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Knjigas'
CREATE TABLE [dbo].[Knjigas] (
    [ID_Knjige] nvarchar(max)  NOT NULL,
    [Autor] nvarchar(max)  NOT NULL,
    [Naziv] nvarchar(max)  NOT NULL,
    [Kolicina] int  NOT NULL,
    [Zanr] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Izdanjes'
CREATE TABLE [dbo].[Izdanjes] (
    [Rbr_Izdanja] nvarchar(max)  NOT NULL,
    [KnjigaID_Knjige] nvarchar(max)  NOT NULL,
    [IzdavacID_Izdavaca] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Izdavacs'
CREATE TABLE [dbo].[Izdavacs] (
    [ID_Izdavaca] nvarchar(max)  NOT NULL,
    [Naziv_Izdavaca] nvarchar(max)  NOT NULL,
    [IzdanjeRbr_Izdanja] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Primeraks'
CREATE TABLE [dbo].[Primeraks] (
    [ID_Primerka] nvarchar(max)  NOT NULL,
    [IzdanjeRbr_Izdanja] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Za_Iznajmljivanje'
CREATE TABLE [dbo].[Za_Iznajmljivanje] (
    [Datum_Iznajmljivanja] nvarchar(max)  NOT NULL,
    [PrimerakID_Primerka] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Za_Prodaju'
CREATE TABLE [dbo].[Za_Prodaju] (
    [Cena_Knjige] bigint  NOT NULL,
    [PrimerakID_Primerka] nvarchar(max)  NOT NULL,
    [Osoba_JMBG] int  NOT NULL
);
GO

-- Creating table 'BibliotekaClan'
CREATE TABLE [dbo].[BibliotekaClan] (
    [Bibliotekas_PIB] nvarchar(max)  NOT NULL,
    [Clans_ID_clana] int  NOT NULL
);
GO

-- Creating table 'BibliotekaKnjiga'
CREATE TABLE [dbo].[BibliotekaKnjiga] (
    [Bibliotekas_PIB] nvarchar(max)  NOT NULL,
    [Knjigas_ID_Knjige] nvarchar(max)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [JMBG] in table 'Osobas'
ALTER TABLE [dbo].[Osobas]
ADD CONSTRAINT [PK_Osobas]
    PRIMARY KEY CLUSTERED ([JMBG] ASC);
GO

-- Creating primary key on [ID_clana] in table 'Clans'
ALTER TABLE [dbo].[Clans]
ADD CONSTRAINT [PK_Clans]
    PRIMARY KEY CLUSTERED ([ID_clana] ASC);
GO

-- Creating primary key on [Naziv] in table 'Clanarinas'
ALTER TABLE [dbo].[Clanarinas]
ADD CONSTRAINT [PK_Clanarinas]
    PRIMARY KEY CLUSTERED ([Naziv] ASC);
GO

-- Creating primary key on [ID_Bibliotekara] in table 'Bibliotekars'
ALTER TABLE [dbo].[Bibliotekars]
ADD CONSTRAINT [PK_Bibliotekars]
    PRIMARY KEY CLUSTERED ([ID_Bibliotekara] ASC);
GO

-- Creating primary key on [PIB] in table 'Bibliotekas'
ALTER TABLE [dbo].[Bibliotekas]
ADD CONSTRAINT [PK_Bibliotekas]
    PRIMARY KEY CLUSTERED ([PIB] ASC);
GO

-- Creating primary key on [ID_Knjige] in table 'Knjigas'
ALTER TABLE [dbo].[Knjigas]
ADD CONSTRAINT [PK_Knjigas]
    PRIMARY KEY CLUSTERED ([ID_Knjige] ASC);
GO

-- Creating primary key on [Rbr_Izdanja] in table 'Izdanjes'
ALTER TABLE [dbo].[Izdanjes]
ADD CONSTRAINT [PK_Izdanjes]
    PRIMARY KEY CLUSTERED ([Rbr_Izdanja] ASC);
GO

-- Creating primary key on [ID_Izdavaca] in table 'Izdavacs'
ALTER TABLE [dbo].[Izdavacs]
ADD CONSTRAINT [PK_Izdavacs]
    PRIMARY KEY CLUSTERED ([ID_Izdavaca] ASC);
GO

-- Creating primary key on [ID_Primerka] in table 'Primeraks'
ALTER TABLE [dbo].[Primeraks]
ADD CONSTRAINT [PK_Primeraks]
    PRIMARY KEY CLUSTERED ([ID_Primerka] ASC);
GO

-- Creating primary key on [PrimerakID_Primerka] in table 'Za_Iznajmljivanje'
ALTER TABLE [dbo].[Za_Iznajmljivanje]
ADD CONSTRAINT [PK_Za_Iznajmljivanje]
    PRIMARY KEY CLUSTERED ([PrimerakID_Primerka] ASC);
GO

-- Creating primary key on [PrimerakID_Primerka] in table 'Za_Prodaju'
ALTER TABLE [dbo].[Za_Prodaju]
ADD CONSTRAINT [PK_Za_Prodaju]
    PRIMARY KEY CLUSTERED ([PrimerakID_Primerka] ASC);
GO

-- Creating primary key on [Bibliotekas_PIB], [Clans_ID_clana] in table 'BibliotekaClan'
ALTER TABLE [dbo].[BibliotekaClan]
ADD CONSTRAINT [PK_BibliotekaClan]
    PRIMARY KEY CLUSTERED ([Bibliotekas_PIB], [Clans_ID_clana] ASC);
GO

-- Creating primary key on [Bibliotekas_PIB], [Knjigas_ID_Knjige] in table 'BibliotekaKnjiga'
ALTER TABLE [dbo].[BibliotekaKnjiga]
ADD CONSTRAINT [PK_BibliotekaKnjiga]
    PRIMARY KEY CLUSTERED ([Bibliotekas_PIB], [Knjigas_ID_Knjige] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [OsobaJMBG] in table 'Clans'
ALTER TABLE [dbo].[Clans]
ADD CONSTRAINT [FK_OsobaClan]
    FOREIGN KEY ([OsobaJMBG])
    REFERENCES [dbo].[Osobas]
        ([JMBG])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_OsobaClan'
CREATE INDEX [IX_FK_OsobaClan]
ON [dbo].[Clans]
    ([OsobaJMBG]);
GO

-- Creating foreign key on [Clanarina_Naziv] in table 'Clans'
ALTER TABLE [dbo].[Clans]
ADD CONSTRAINT [FK_ClanClanarina]
    FOREIGN KEY ([Clanarina_Naziv])
    REFERENCES [dbo].[Clanarinas]
        ([Naziv])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClanClanarina'
CREATE INDEX [IX_FK_ClanClanarina]
ON [dbo].[Clans]
    ([Clanarina_Naziv]);
GO

-- Creating foreign key on [Clanarina_Naziv] in table 'Bibliotekars'
ALTER TABLE [dbo].[Bibliotekars]
ADD CONSTRAINT [FK_ClanarinaBibliotekar]
    FOREIGN KEY ([Clanarina_Naziv])
    REFERENCES [dbo].[Clanarinas]
        ([Naziv])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ClanarinaBibliotekar'
CREATE INDEX [IX_FK_ClanarinaBibliotekar]
ON [dbo].[Bibliotekars]
    ([Clanarina_Naziv]);
GO

-- Creating foreign key on [BibliotekaPIB] in table 'Bibliotekars'
ALTER TABLE [dbo].[Bibliotekars]
ADD CONSTRAINT [FK_BibliotekaBibliotekar]
    FOREIGN KEY ([BibliotekaPIB])
    REFERENCES [dbo].[Bibliotekas]
        ([PIB])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_BibliotekaBibliotekar'
CREATE INDEX [IX_FK_BibliotekaBibliotekar]
ON [dbo].[Bibliotekars]
    ([BibliotekaPIB]);
GO

-- Creating foreign key on [Bibliotekas_PIB] in table 'BibliotekaClan'
ALTER TABLE [dbo].[BibliotekaClan]
ADD CONSTRAINT [FK_BibliotekaClan_Biblioteka]
    FOREIGN KEY ([Bibliotekas_PIB])
    REFERENCES [dbo].[Bibliotekas]
        ([PIB])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Clans_ID_clana] in table 'BibliotekaClan'
ALTER TABLE [dbo].[BibliotekaClan]
ADD CONSTRAINT [FK_BibliotekaClan_Clan]
    FOREIGN KEY ([Clans_ID_clana])
    REFERENCES [dbo].[Clans]
        ([ID_clana])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_BibliotekaClan_Clan'
CREATE INDEX [IX_FK_BibliotekaClan_Clan]
ON [dbo].[BibliotekaClan]
    ([Clans_ID_clana]);
GO

-- Creating foreign key on [Bibliotekas_PIB] in table 'BibliotekaKnjiga'
ALTER TABLE [dbo].[BibliotekaKnjiga]
ADD CONSTRAINT [FK_BibliotekaKnjiga_Biblioteka]
    FOREIGN KEY ([Bibliotekas_PIB])
    REFERENCES [dbo].[Bibliotekas]
        ([PIB])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Knjigas_ID_Knjige] in table 'BibliotekaKnjiga'
ALTER TABLE [dbo].[BibliotekaKnjiga]
ADD CONSTRAINT [FK_BibliotekaKnjiga_Knjiga]
    FOREIGN KEY ([Knjigas_ID_Knjige])
    REFERENCES [dbo].[Knjigas]
        ([ID_Knjige])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_BibliotekaKnjiga_Knjiga'
CREATE INDEX [IX_FK_BibliotekaKnjiga_Knjiga]
ON [dbo].[BibliotekaKnjiga]
    ([Knjigas_ID_Knjige]);
GO

-- Creating foreign key on [KnjigaID_Knjige] in table 'Izdanjes'
ALTER TABLE [dbo].[Izdanjes]
ADD CONSTRAINT [FK_KnjigaIzdanje]
    FOREIGN KEY ([KnjigaID_Knjige])
    REFERENCES [dbo].[Knjigas]
        ([ID_Knjige])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_KnjigaIzdanje'
CREATE INDEX [IX_FK_KnjigaIzdanje]
ON [dbo].[Izdanjes]
    ([KnjigaID_Knjige]);
GO

-- Creating foreign key on [IzdavacID_Izdavaca] in table 'Izdanjes'
ALTER TABLE [dbo].[Izdanjes]
ADD CONSTRAINT [FK_IzdanjeIzdavac]
    FOREIGN KEY ([IzdavacID_Izdavaca])
    REFERENCES [dbo].[Izdavacs]
        ([ID_Izdavaca])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_IzdanjeIzdavac'
CREATE INDEX [IX_FK_IzdanjeIzdavac]
ON [dbo].[Izdanjes]
    ([IzdavacID_Izdavaca]);
GO

-- Creating foreign key on [IzdanjeRbr_Izdanja] in table 'Primeraks'
ALTER TABLE [dbo].[Primeraks]
ADD CONSTRAINT [FK_IzdanjePrimerak]
    FOREIGN KEY ([IzdanjeRbr_Izdanja])
    REFERENCES [dbo].[Izdanjes]
        ([Rbr_Izdanja])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_IzdanjePrimerak'
CREATE INDEX [IX_FK_IzdanjePrimerak]
ON [dbo].[Primeraks]
    ([IzdanjeRbr_Izdanja]);
GO

-- Creating foreign key on [PrimerakID_Primerka] in table 'Za_Iznajmljivanje'
ALTER TABLE [dbo].[Za_Iznajmljivanje]
ADD CONSTRAINT [FK_PrimerakZa_Iznajmljivanje]
    FOREIGN KEY ([PrimerakID_Primerka])
    REFERENCES [dbo].[Primeraks]
        ([ID_Primerka])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [PrimerakID_Primerka] in table 'Za_Prodaju'
ALTER TABLE [dbo].[Za_Prodaju]
ADD CONSTRAINT [FK_PrimerakZa_Prodaju]
    FOREIGN KEY ([PrimerakID_Primerka])
    REFERENCES [dbo].[Primeraks]
        ([ID_Primerka])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Za_Iznajmljivanje_PrimerakID_Primerka] in table 'Clans'
ALTER TABLE [dbo].[Clans]
ADD CONSTRAINT [FK_Za_IznajmljivanjeClan]
    FOREIGN KEY ([Za_Iznajmljivanje_PrimerakID_Primerka])
    REFERENCES [dbo].[Za_Iznajmljivanje]
        ([PrimerakID_Primerka])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Za_IznajmljivanjeClan'
CREATE INDEX [IX_FK_Za_IznajmljivanjeClan]
ON [dbo].[Clans]
    ([Za_Iznajmljivanje_PrimerakID_Primerka]);
GO

-- Creating foreign key on [Osoba_JMBG] in table 'Za_Prodaju'
ALTER TABLE [dbo].[Za_Prodaju]
ADD CONSTRAINT [FK_Za_ProdajuOsoba]
    FOREIGN KEY ([Osoba_JMBG])
    REFERENCES [dbo].[Osobas]
        ([JMBG])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_Za_ProdajuOsoba'
CREATE INDEX [IX_FK_Za_ProdajuOsoba]
ON [dbo].[Za_Prodaju]
    ([Osoba_JMBG]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------